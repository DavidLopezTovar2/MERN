


function muestraSiElNiñoPuedeSubirALaMontañaRusa(estatura){
    if (estatura > 52){
        console.log("¡Súbete, chico!");
    } else {
        console.log("Lo siento, chico. Tal vez el próximo año");
    }
}

var alturaNiño = 32; 
muestraSiElNiñoPuedeSubirALaMontañaRusa(alturaNiño);
